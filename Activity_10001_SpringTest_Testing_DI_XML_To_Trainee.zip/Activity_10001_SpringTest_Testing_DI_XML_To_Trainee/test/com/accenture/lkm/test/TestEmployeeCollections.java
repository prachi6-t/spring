package com.accenture.lkm.test;

import org.springframework.beans.factory.annotation.Autowired;

import com.accenture.lkm.Employee;

//Write valid annotations
public class TestEmployeeCollections {
	@Autowired
	private Employee employee;

	

}
