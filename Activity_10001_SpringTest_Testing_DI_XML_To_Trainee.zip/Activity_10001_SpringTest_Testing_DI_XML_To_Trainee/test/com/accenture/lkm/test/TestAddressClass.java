package com.accenture.lkm.test;

import org.springframework.beans.factory.annotation.Autowired;

import com.accenture.lkm.Address;
//Write valid annotations
public class TestAddressClass {
	@Autowired
	private Address address;
	
}