package com.accenture.lkm.test;

import org.springframework.beans.factory.annotation.Autowired;

import com.accenture.lkm.Employee;

//Write valid annotations
public class TestEmployeeClass {
	@Autowired
	private Employee employee;
	
}